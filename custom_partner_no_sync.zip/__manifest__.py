{
    'name': 'Partner Fields No Sync',
    'version': '1.0',
    'author': 'Tu Nombre',
    'category': 'Contacts',
    'summary': 'Disable address/VAT sync and readonly fields',
    'depends': ['base'],
    'data': [
        'views/res_partner_views.xml'
    ],
    'installable': True,
    'application': False,
    'license': 'LGPL-3',
}